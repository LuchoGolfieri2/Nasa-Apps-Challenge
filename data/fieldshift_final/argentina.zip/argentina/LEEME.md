# Field Shift: Argentina v1 (Buenos Aires), 2026-11-15

Datos para probar los modelos del Corn Belt en Argentina. Salen del análisis de análogos del repo
(`src/analogos/`, PR 148, mergeado en `main` como a4e8149). El informe completo, con método, supuestos y
fuentes, está en `docs/analogos_argentina.md`. El mapa está en `docs/fig/analogos_argentina.png`.

Ningún valor se inventó: los faltantes quedan vacíos.

## Respuesta corta

- **Buenos Aires es la provincia más parecida al Corn Belt.** 12 de sus 135 departamentos caen dentro del clima
  de los 919 condados (10 estados, con Kansas), todos del sur bonaerense. La Pampa tiene 3.
- **La zona núcleo queda afuera del dominio climático**: octubres más cálidos y marzos más lluviosos que cualquier
  condado. Sumar el suelo de SoilGrids casi no cambia el dominio.
- **Parecerse en clima no alcanza para rendir parecido.** El sur bonaerense rinde más o menos la mitad que sus 3
  condados análogos: ratio de 0,52 en maíz, 0,49 en soja y 0,75 en trigo. La zona núcleo, fuera de dominio,
  rinde 0,95 en maíz, 1,16 en soja y 1,15 en trigo.

## Archivos (`datos/`)

La clave de Argentina es `id_depto_indec`: 5 dígitos, 2 de la provincia y 3 del departamento (Buenos Aires = 06).
`anio` es el segundo año de la campaña: 2024 = campaña 2023/24, también para el trigo.

| archivo | filas | qué tiene |
|---|---|---|
| `analogos_departamento.csv` | 529 | Una fila por departamento argentino: condados análogos (`fips_analogo`, `_2`, `_3`), distancia, Mahalanobis, variables fuera de rango, `dentro_dominio`, y lo mismo con suelo (columnas `_cs`). Acá la clave es `id_depto`. |
| `analogos_provincia.csv` | 24 | Resumen por provincia. |
| `analogos_condado_ref.csv` | 919 | Distancia y Mahalanobis de cada condado contra su propia nube (la referencia del dominio). |
| `analogos_meta.json` | | Variables usadas, componentes, límite de Mahalanobis (p99) y período. |
| `clima_anual_ba.csv` | 3.510 | 135 departamentos de Buenos Aires × 2000–2025. **Mismas columnas que `clima_anual.csv` de EE.UU.**, de NASA POWER diario, con la temporada corrida 6 meses (ver abajo). |
| `suelo_sg.csv` | 1.138 | SoilGrids v2.0, media 0–30 cm a 1 km: arcilla, arena, carbono orgánico y pH. `lado` = `ar` (219 departamentos de las 5 provincias núcleo) o `us` (919 condados; `id` = `fips`). |
| `rendimiento_ar.csv` | 19.351 | MAGyP, estimaciones agrícolas por departamento: maíz, soja y trigo, campañas 2000/01 a 2024/25. Superficie en ha, producción en t, `rend_kgha`. Los rindes 0 sin cosecha van vacíos con `flag_magyp` = `0_sin_cosecha`. |
| `rendimiento_comparacion.csv` | 922 | Por departamento y cultivo: mediana argentina contra p10, mediana y p90 de los 3 condados análogos (kg/ha), `ratio_ar_us` y percentil del rinde argentino en la distribución de EE.UU. |

## Corrimiento de la temporada en `clima_anual_ba.csv`

Los nombres de las columnas son los de EE.UU., pero los meses son los del hemisferio sur. Con `anio` = 2024:

| columna | meses reales en Argentina |
|---|---|
| temporada (`prec_temporada_mm`, `gdd_temporada`, `deficit_temporada_mm`) | octubre de 2023 a marzo de 2024 |
| `prec_invierno_previo_mm` | mayo a septiembre de 2023 |
| `prec_jul_mm`, `tmax_jul_c`, `dias_tmax_gt30_jul` (floración del maíz) | **enero** de 2024 |
| `prec_ago_mm` (llenado de la soja) | **febrero** de 2024 |
| `doy_ultima_helada`, `doy_primera_helada` | día 1 = 1 de julio de 2023 |

## Ojo antes de usarlo en un modelo

- **Heladas fuera de rango**: el período libre de heladas mediano es de 291 días, contra 180 en los condados.
  `doy_primera_helada` está vacío en el 18 % de los años (no heló) y `doy_ultima_helada` en el 10 %. Un modelo que
  use esas columnas extrapola.
- **Radiación**: la región pampeana tiene entre 2 y 4 MJ/m²/día más que sus análogos en la temporada.
- **Suelo**: es SoilGrids, no gSSURGO. Para usar suelo en los dos lados, entrená con las columnas de
  `suelo_sg.csv` de los condados, no con las de `suelo_terreno`. SoilGrids no tiene la profundidad de la tosca.
- **Lluvia**: solo POWER. IMERG no se bajó para Argentina.
- **Una sola celda de POWER por departamento** (el centroide, grilla de 0,5° × 0,625°).
- **El MAGyP no es de la NASA** ni del USDA: se usa para validar.
- Las tendencias por década de 2000 van vacías.

## Otros

- `codigo/`: los scripts que generaron estos archivos, copia de `src/analogos/` en `main`.
- `manifest_analogos.csv`: una fila por archivo bajado (fuente, producto, fecha y consulta).
