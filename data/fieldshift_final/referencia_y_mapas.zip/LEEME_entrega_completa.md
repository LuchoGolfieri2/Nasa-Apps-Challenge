# Field Shift: todos los datos al 2026-11-15

Un solo zip con los datos procesados que hay hasta ahora: **11 estados y 972 condados**. Ningún valor se
inventó: cada uno sale de las fuentes de la NASA, el USDA y el USGS, y los faltantes quedan vacíos (CLAUDE.md,
sección 4).

**Para empezar: `unido_11_estados/`**

- Trae `tabla_anual.csv` (fips × anio × cultivo) y `tabla_mensual.csv` (fips × anio × mes) de los 11 estados, con
  **exactamente las mismas columnas, en el mismo orden, que la v4** (las mismas de la v3): 110 y 68 columnas.
  `diccionario.csv` es el de la v4 y describe cada columna; sus columnas `desde`, `hasta` y `pct_vacias` son solo de IA, IL e IN.
- Cómo se armó: OH/NE/MN, MO/WI/SD, KS y ND se pasaron por el mismo `src/merge.py` de la v3, con sus CSV por paquete tal
  cual. Antes se comprobó que los 19 archivos por paquete que están en los dos lados tienen columnas idénticas
  (mismo nombre y orden). Los scripts y sus resúmenes están en `scripts/`.
- **Aptitud FAO GAEZ (16 columnas) y PRISM (4) están en los 11 estados** (T156, 2026-11-15). Para los 8 estados
  nuevos se corrió el mismo código del loop (`src/aptitud/process.py` y `src/validacion/process.py`) sobre los mismos
  archivos crudos, que ya cubrían todo EE.UU. o el mundo, con los condados y la máscara agrícola de cada grupo.
  Quedan en la carpeta `aptitud/` y `validacion/` de cada grupo. PRISM contra POWER en los 8 estados: correlación
  0,95 en lluvia mensual y 0,995 en máxima.
  - En 21 condados del oeste seco o del norte frío (NE, SD, ND, KS y WI) algún `rend_alcanzable_*` vale 0: es el valor de GAEZ para "sin
    rendimiento alcanzable en secano", no un faltante (GAEZ usa −1 y −9 para eso, y esos quedan vacíos).
- **17 columnas siguen con dato solo en IA, IL e IN**: teledetección Landsat (7), CoCoRaHS (2), ECOSTRESS (4) y napa
  y caudales (4). Hay que bajarlas estado por estado y no llegaban antes del cierre. `columnas_vacias.csv` da el %
  de vacías de cada columna por grupo.
- `referencia/condados.csv` tiene los 972 condados. El estado son los dos primeros dígitos de `fips`.

**Por grupo**

- `ia_il_in_v4/` es la entrega v4 tal cual: la v3 con ECOSTRESS ampliado a septiembre de 2018 – diciembre de 2025
  (es lo único que cambió). Tiene `GUIA.md`, las tablas por
  condado (`condado/`, incluidas las tablas unidas `tabla_anual.csv` y `tabla_mensual.csv`) y los 10 lotes por píxel
  (`lotes/`).
- `oh_ne_mn/`, `mo_wi_sd/`, `ks/` y `nd/` son los zips de los releases de GitHub, bajados y verificados contra sus `.sha256`.
  Hay una carpeta por paquete, con sus CSV en `data/processed/<paquete>/`, su data card en `docs/datasets/`,
  `manifest.csv` y `data/reference/` (condados y años). En `oh_ne_mn/`, `mo_wi_sd/` y `nd/`, `base/` trae los polígonos
  (`condados.gpkg`); el release de KS no trae `base/`. Sus tablas unidas están en `unido_11_estados/`. Los archivos diarios, de 16 días y semanales (los "extras" de la v3) están
  acá, con las mismas columnas que los de `ia_il_in_v4/condado/extras/`.

**Qué falta**

- Ningún estado de los planeados: están los 11.

**Problemas conocidos**

Están en el data card de cada paquete y en las notas de cada release. Los principales:

- Todos los grupos: el NDVI y la LST de MODIS están vacíos en todos los condados de 2025-07 a 2025-10, por huecos
  de Planetary Computer. Los rellena la tarea T100.
- KS (release del 2026-11-15, 15:33 UTC):
  - Columnas idénticas a la v3 en los 19 archivos comunes; % de vacías no más alto que en OH/NE/MN ni MO/WI/SD.
  - Ningún rendimiento 0; 93 valores `(D)` vacíos con su `flag_nass`. 2024 tiene menos condados con rendimiento
    (104) porque NASS publicó menos.
  - Russell (20167), maíz 2002, 18 bu/ac: valor real de NASS.
  - Sin alfalfa ni heno con rendimiento por condado en NASS.
- ND (release del 2026-11-15):
  - Columnas idénticas a la v3 en los 19 archivos comunes.
  - El NDVI de MODIS falta en el 15 % de los condado-mes (contra 2–6 % en el resto), solo de noviembre a marzo:
    son píxeles con nieve que el filtro de calidad descarta. No es un hueco de descarga.
  - Ningún rendimiento 0; 58 valores `(D)` vacíos. ND tiene menos condados con trigo de invierno (el trigo de
    ND es casi todo de primavera, que no está entre los cultivos del proyecto).
  - 36 meses de NLDAS que no habían bajado se volvieron a bajar antes de publicar: `et_mm` y el paquete
    `nldas` están completos.
- MO, WI, SD:
  - 19 rendimientos que NASS publica como 0 sin cosecha para grano (maíz que fue todo a silo en el oeste de SD,
    y avena) están vacíos, con `flag_nass` = `0_sin_cosecha_grano`.
  - 6 rendimientos bajos son reales (sequías en SD).
  - `ndvi_soja` de WI viene casi vacío por el umbral de 75 % de pureza del píxel (`docs/qa/mo_wi_sd.md` en el repo).

## `unido_11_estados/`: los 11 estados juntos, con las columnas de la v4 (T155)

972 condados (IA, IL, IN, KS, MN, MO, ND, NE, OH, SD, WI).

| archivo | filas | columnas | años (`anio`) | condados con dato |
|---|---|---|---|---|
| `unido_11_estados/columnas_vacias.csv` | 178 | 7 |  |  |
| `unido_11_estados/diccionario.csv` | 266 | 15 |  |  |
| `unido_11_estados/tabla_anual.csv` | 83.204 | 110 | 2000–2025 | 970 |
| `unido_11_estados/tabla_mensual.csv` | 303.264 | 68 | 2000–2025 | 972 |

## `ia_il_in_v4/`: IA, IL, IN: entrega v4 al equipo de ML (loop autónomo, corrida v4-20261115, commit 8ceb262)

293 condados (IA, IL, IN).

| archivo | filas | columnas | años (`anio`) | condados con dato |
|---|---|---|---|---|
| `ia_il_in_v4/condado/archivos.csv` | 15 | 8 |  |  |
| `ia_il_in_v4/condado/diccionario.csv` | 266 | 15 |  |  |
| `ia_il_in_v4/condado/extras/agua_diario.csv` | 1.150.904 | 5 | 2015–2025 | 293 |
| `ia_il_in_v4/condado/extras/agua_semanal.csv` | 351.307 | 6 | 2003–2025 | 293 |
| `ia_il_in_v4/condado/extras/clima_diario.csv` | 2.782.621 | 15 | 2000–2025 | 293 |
| `ia_il_in_v4/condado/extras/economia_anual.csv` | 312 | 9 | 2000–2025 |  |
| `ia_il_in_v4/condado/extras/economia_forrajes_anual.csv` | 156 | 5 | 2000–2025 |  |
| `ia_il_in_v4/condado/extras/ecostress_mensual.csv` | 20.217 | 7 | 2018–2025 | 293 |
| `ia_il_in_v4/condado/extras/nldas_mensual.csv` | 91.416 | 9 | 2000–2025 | 293 |
| `ia_il_in_v4/condado/extras/practicas_censo.csv` | 879 | 6 |  | 293 |
| `ia_il_in_v4/condado/extras/rotacion_secuencia.csv` | 3.223 | 9 |  | 293 |
| `ia_il_in_v4/condado/extras/teledeteccion_anual.csv` | 4.393 | 9 | 2011–2025 | 293 |
| `ia_il_in_v4/condado/extras/vegetacion_16d.csv` | 171.112 | 8 | 2000–2025 | 293 |
| `ia_il_in_v4/condado/tabla_anual.csv` | 25.070 | 110 | 2000–2025 | 293 |
| `ia_il_in_v4/condado/tabla_mensual.csv` | 91.416 | 68 | 2000–2025 | 293 |
| `ia_il_in_v4/lotes/archivos.csv` | 15 | 7 |  |  |
| `ia_il_in_v4/lotes/clima_lote_anual.csv` | 260 | 21 | 2000–2025 | 5 |
| `ia_il_in_v4/lotes/clima_lote_diario.csv` | 94.970 | 16 | 2000–2025 | 5 |
| `ia_il_in_v4/lotes/cultivo_px_anual.csv` | 113.940 | 7 | 2008–2025 | 5 |
| `ia_il_in_v4/lotes/diccionario.csv` | 194 | 11 |  |  |
| `ia_il_in_v4/lotes/drenaje_px.csv` | 6.330 | 4 |  | 5 |
| `ia_il_in_v4/lotes/lotes.csv` | 10 | 19 |  | 5 |
| `ia_il_in_v4/lotes/lotes_anual.csv` | 180 | 9 | 2008–2025 | 5 |
| `ia_il_in_v4/lotes/pixeles.csv` | 6.330 | 10 |  | 5 |
| `ia_il_in_v4/lotes/suelo_desnudo_px.csv` | 158.470 | 18 | 2000–2025 | 5 |
| `ia_il_in_v4/lotes/suelo_desnudo_px_compuesto.csv` | 6.330 | 10 |  | 5 |
| `ia_il_in_v4/lotes/suelo_mukey.csv` | 55 | 25 |  |  |
| `ia_il_in_v4/lotes/suelo_px.csv` | 8.859 | 5 |  | 5 |
| `ia_il_in_v4/lotes/terreno_px.csv` | 6.330 | 17 |  | 5 |
| `ia_il_in_v4/lotes/vegetacion_px_anual.csv` | 164.580 | 14 | 2000–2025 | 5 |
| `ia_il_in_v4/lotes/vegetacion_px_obs.csv` | 2.958.016 | 19 | 2000–2025 | 5 |

## `oh_ne_mn/`: OH, NE, MN: release `datos-oh-ne-mn` de GitHub (máquinas del equipo)

268 condados (MN, NE, OH).

| archivo | filas | columnas | años (`anio`) | condados con dato |
|---|---|---|---|---|
| `oh_ne_mn/agua/data/processed/agua/agua_diario.csv` | 1.052.704 | 5 | 2015–2025 | 268 |
| `oh_ne_mn/agua/data/processed/agua/agua_mensual.csv` | 34.572 | 9 | 2015–2025 | 268 |
| `oh_ne_mn/agua/data/processed/agua/agua_semanal.csv` | 321.332 | 6 | 2003–2025 | 268 |
| `oh_ne_mn/aptitud/data/processed/aptitud/aptitud_estatico.csv` | 268 | 17 |  | 268 |
| `oh_ne_mn/clima/data/processed/clima/clima_anual.csv` | 6.968 | 15 | 2000–2025 | 268 |
| `oh_ne_mn/clima/data/processed/clima/clima_diario.csv` | 2.545.196 | 15 | 2000–2025 | 268 |
| `oh_ne_mn/clima/data/processed/clima/clima_mensual.csv` | 83.616 | 29 | 2000–2025 | 268 |
| `oh_ne_mn/cultivos/data/processed/cultivos/fenologia_estado.csv` | 156 | 7 | 2000–2025 |  |
| `oh_ne_mn/cultivos/data/processed/cultivos/practicas_censo.csv` | 804 | 6 |  | 268 |
| `oh_ne_mn/cultivos/data/processed/cultivos/produccion_anual.csv` | 23.016 | 11 | 2000–2025 | 267 |
| `oh_ne_mn/cultivos/data/processed/cultivos/rotacion_anual.csv` | 4.824 | 13 | 2008–2025 | 268 |
| `oh_ne_mn/cultivos/data/processed/cultivos/rotacion_secuencia.csv` | 2.948 | 9 |  | 268 |
| `oh_ne_mn/economia/data/processed/economia/economia_anual.csv` | 312 | 9 | 2000–2025 |  |
| `oh_ne_mn/economia/data/processed/economia/economia_forrajes_anual.csv` | 156 | 5 | 2000–2025 |  |
| `oh_ne_mn/nldas/data/processed/nldas/nldas_mensual.csv` | 83.616 | 9 | 2000–2025 | 268 |
| `oh_ne_mn/paisaje/data/processed/paisaje/paisaje_anual.csv` | 6.700 | 9 | 2000–2024 | 268 |
| `oh_ne_mn/suelo_terreno/data/processed/suelo_terreno/suelo_terreno_estatico.csv` | 268 | 25 |  | 268 |
| `oh_ne_mn/validacion/data/processed/validacion/validacion_mensual.csv` | 83.616 | 9 | 2000–2025 | 268 |
| `oh_ne_mn/vegetacion/data/processed/vegetacion/fenologia_anual.csv` | 6.968 | 12 | 2000–2025 | 268 |
| `oh_ne_mn/vegetacion/data/processed/vegetacion/vegetacion_16d.csv` | 156.512 | 8 | 2000–2025 | 268 |
| `oh_ne_mn/vegetacion/data/processed/vegetacion/vegetacion_mensual.csv` | 82.276 | 16 | 2000–2025 | 268 |

## `mo_wi_sd/`: MO, WI, SD: release `datos-mo-wi-sd` de GitHub (máquinas del equipo)

253 condados (MO, SD, WI).

| archivo | filas | columnas | años (`anio`) | condados con dato |
|---|---|---|---|---|
| `mo_wi_sd/agua/data/processed/agua/agua_diario.csv` | 993.784 | 5 | 2015–2025 | 253 |
| `mo_wi_sd/agua/data/processed/agua/agua_mensual.csv` | 32.637 | 9 | 2015–2025 | 253 |
| `mo_wi_sd/agua/data/processed/agua/agua_semanal.csv` | 303.347 | 6 | 2003–2025 | 253 |
| `mo_wi_sd/aptitud/data/processed/aptitud/aptitud_estatico.csv` | 253 | 17 |  | 253 |
| `mo_wi_sd/clima/data/processed/clima/clima_anual.csv` | 6.578 | 15 | 2000–2025 | 253 |
| `mo_wi_sd/clima/data/processed/clima/clima_diario.csv` | 2.402.741 | 15 | 2000–2025 | 253 |
| `mo_wi_sd/clima/data/processed/clima/clima_mensual.csv` | 78.936 | 29 | 2000–2025 | 253 |
| `mo_wi_sd/cultivos/data/processed/cultivos/fenologia_estado.csv` | 156 | 7 | 2000–2025 |  |
| `mo_wi_sd/cultivos/data/processed/cultivos/practicas_censo.csv` | 759 | 6 |  | 253 |
| `mo_wi_sd/cultivos/data/processed/cultivos/produccion_anual.csv` | 20.634 | 11 | 2000–2025 | 252 |
| `mo_wi_sd/cultivos/data/processed/cultivos/rotacion_anual.csv` | 4.554 | 13 | 2008–2025 | 253 |
| `mo_wi_sd/cultivos/data/processed/cultivos/rotacion_secuencia.csv` | 2.783 | 9 |  | 253 |
| `mo_wi_sd/economia/data/processed/economia/economia_anual.csv` | 312 | 9 | 2000–2025 |  |
| `mo_wi_sd/economia/data/processed/economia/economia_forrajes_anual.csv` | 156 | 5 | 2000–2025 |  |
| `mo_wi_sd/nldas/data/processed/nldas/nldas_mensual.csv` | 78.936 | 9 | 2000–2025 | 253 |
| `mo_wi_sd/paisaje/data/processed/paisaje/paisaje_anual.csv` | 6.325 | 9 | 2000–2024 | 253 |
| `mo_wi_sd/suelo_terreno/data/processed/suelo_terreno/suelo_terreno_estatico.csv` | 253 | 25 |  | 253 |
| `mo_wi_sd/validacion/data/processed/validacion/validacion_mensual.csv` | 78.936 | 9 | 2000–2025 | 253 |
| `mo_wi_sd/vegetacion/data/processed/vegetacion/fenologia_anual.csv` | 6.578 | 12 | 2000–2025 | 253 |
| `mo_wi_sd/vegetacion/data/processed/vegetacion/vegetacion_16d.csv` | 147.752 | 8 | 2000–2025 | 253 |
| `mo_wi_sd/vegetacion/data/processed/vegetacion/vegetacion_mensual.csv` | 77.671 | 16 | 2000–2025 | 253 |

## `ks/`: KS: release `datos-ks` de GitHub (max-2, T013)

105 condados (KS).

| archivo | filas | columnas | años (`anio`) | condados con dato |
|---|---|---|---|---|
| `ks/agua/data/processed/agua/agua_diario.csv` | 412.440 | 5 | 2015–2025 | 105 |
| `ks/agua/data/processed/agua/agua_mensual.csv` | 13.545 | 9 | 2015–2025 | 105 |
| `ks/agua/data/processed/agua/agua_semanal.csv` | 125.895 | 6 | 2003–2025 | 105 |
| `ks/aptitud/data/processed/aptitud/aptitud_estatico.csv` | 105 | 17 |  | 105 |
| `ks/clima/data/processed/clima/clima_anual.csv` | 2.730 | 15 | 2000–2025 | 105 |
| `ks/clima/data/processed/clima/clima_diario.csv` | 997.185 | 15 | 2000–2025 | 105 |
| `ks/clima/data/processed/clima/clima_mensual.csv` | 32.760 | 29 | 2000–2025 | 105 |
| `ks/cultivos/data/processed/cultivos/fenologia_estado.csv` | 52 | 7 | 2000–2025 |  |
| `ks/cultivos/data/processed/cultivos/practicas_censo.csv` | 315 | 6 |  | 105 |
| `ks/cultivos/data/processed/cultivos/produccion_anual.csv` | 9.286 | 11 | 2000–2025 | 105 |
| `ks/cultivos/data/processed/cultivos/rotacion_anual.csv` | 1.890 | 13 | 2008–2025 | 105 |
| `ks/cultivos/data/processed/cultivos/rotacion_secuencia.csv` | 1.155 | 9 |  | 105 |
| `ks/economia/data/processed/economia/economia_anual.csv` | 104 | 9 | 2000–2025 |  |
| `ks/economia/data/processed/economia/economia_forrajes_anual.csv` | 52 | 5 | 2000–2025 |  |
| `ks/nldas/data/processed/nldas/nldas_mensual.csv` | 32.760 | 9 | 2000–2025 | 105 |
| `ks/paisaje/data/processed/paisaje/paisaje_anual.csv` | 2.625 | 9 | 2000–2024 | 105 |
| `ks/suelo_terreno/data/processed/suelo_terreno/suelo_terreno_estatico.csv` | 105 | 25 |  | 105 |
| `ks/validacion/data/processed/validacion/validacion_mensual.csv` | 32.760 | 9 | 2000–2025 | 105 |
| `ks/vegetacion/data/processed/vegetacion/fenologia_anual.csv` | 2.730 | 12 | 2000–2025 | 105 |
| `ks/vegetacion/data/processed/vegetacion/vegetacion_16d.csv` | 61.320 | 8 | 2000–2025 | 105 |
| `ks/vegetacion/data/processed/vegetacion/vegetacion_mensual.csv` | 32.235 | 16 | 2000–2025 | 105 |

## `nd/`: ND: release `datos-nd` de GitHub (max-1, T149)

53 condados (ND).

| archivo | filas | columnas | años (`anio`) | condados con dato |
|---|---|---|---|---|
| `nd/agua/data/processed/agua/agua_diario.csv` | 208.184 | 5 | 2015–2025 | 53 |
| `nd/agua/data/processed/agua/agua_mensual.csv` | 6.837 | 9 | 2015–2025 | 53 |
| `nd/agua/data/processed/agua/agua_semanal.csv` | 63.547 | 6 | 2003–2025 | 53 |
| `nd/aptitud/data/processed/aptitud/aptitud_estatico.csv` | 53 | 17 |  | 53 |
| `nd/clima/data/processed/clima/clima_anual.csv` | 1.378 | 15 | 2000–2025 | 53 |
| `nd/clima/data/processed/clima/clima_diario.csv` | 503.341 | 15 | 2000–2025 | 53 |
| `nd/clima/data/processed/clima/clima_mensual.csv` | 16.536 | 29 | 2000–2025 | 53 |
| `nd/cultivos/data/processed/cultivos/fenologia_estado.csv` | 52 | 7 | 2000–2025 |  |
| `nd/cultivos/data/processed/cultivos/practicas_censo.csv` | 159 | 6 |  | 53 |
| `nd/cultivos/data/processed/cultivos/produccion_anual.csv` | 5.198 | 11 | 2000–2025 | 53 |
| `nd/cultivos/data/processed/cultivos/rotacion_anual.csv` | 954 | 13 | 2008–2025 | 53 |
| `nd/cultivos/data/processed/cultivos/rotacion_secuencia.csv` | 583 | 9 |  | 53 |
| `nd/economia/data/processed/economia/economia_anual.csv` | 104 | 9 | 2000–2025 |  |
| `nd/economia/data/processed/economia/economia_forrajes_anual.csv` | 52 | 5 | 2000–2025 |  |
| `nd/nldas/data/processed/nldas/nldas_mensual.csv` | 16.536 | 9 | 2000–2025 | 53 |
| `nd/paisaje/data/processed/paisaje/paisaje_anual.csv` | 1.325 | 9 | 2000–2024 | 53 |
| `nd/suelo_terreno/data/processed/suelo_terreno/suelo_terreno_estatico.csv` | 53 | 25 |  | 53 |
| `nd/validacion/data/processed/validacion/validacion_mensual.csv` | 16.536 | 9 | 2000–2025 | 53 |
| `nd/vegetacion/data/processed/vegetacion/fenologia_anual.csv` | 1.378 | 12 | 2000–2025 | 53 |
| `nd/vegetacion/data/processed/vegetacion/vegetacion_16d.csv` | 30.952 | 8 | 2000–2025 | 53 |
| `nd/vegetacion/data/processed/vegetacion/vegetacion_mensual.csv` | 16.271 | 16 | 2000–2025 | 53 |


## `argentina/`: región pampeana (demo de escalabilidad)

Copia de `fieldshift_argentina_v1`: análogos climáticos de los 529 departamentos contra los 919 condados de los 10
estados sin Dakota del Norte (ND se publicó después de ese análisis), clima por
campaña de los 135 departamentos de Buenos Aires con las mismas columnas que `clima_anual.csv` (temporada corrida
6 meses), suelo de SoilGrids y rendimientos del MAGyP para validar. Empezá por `argentina/LEEME.md`.

## `para_front/`: listas y polígonos para el mapa

- `estados_eeuu.csv` (11), `condados_eeuu.csv` y `.geojson` (972, clave `fips`).
- `departamentos_argentina.csv` y `.geojson` (219 departamentos de Buenos Aires, La Pampa, Córdoba, Santa Fe y
  Entre Ríos, clave `id_depto`), con `zona` = `dentro`, `cerca` o `fuera` del dominio climático de los condados.
- Polígonos simplificados para la web, EPSG:4326.
