"""Junta tabla_anual y tabla_mensual de IA/IL/IN (v3) con las de OH/NE/MN y MO/WI/SD armadas con armar_unido.py.

Uso: unir_9.py <v3_condado> <unido_dir> <salida>
Comprueba encabezados idénticos, sin claves repetidas y fips de 5 dígitos que estén en condados.csv; escribe
columnas_vacias.csv (por grupo: % de celdas vacías de cada columna).
"""
import sys
from pathlib import Path

import pandas as pd

V3 = Path(sys.argv[1])
U = Path(sys.argv[2])
OUT = Path(sys.argv[3])
GRUPOS = {"ia_il_in": V3, "oh_ne_mn": U / "oh_ne_mn", "mo_wi_sd": U / "mo_wi_sd", "ks": U / "ks", "nd": U / "nd"}
CLAVES = {"tabla_anual.csv": ["fips", "anio", "cultivo"], "tabla_mensual.csv": ["fips", "anio", "mes"]}

(OUT / "referencia").mkdir(parents=True, exist_ok=True)
leer = lambda p: pd.read_csv(p, dtype=str, keep_default_na=False, na_filter=False, encoding="utf-8")
cond = pd.concat([leer(d / "referencia" / "condados.csv") for d in GRUPOS.values()], ignore_index=True)
assert not cond["fips"].duplicated().any()
cond.sort_values("fips").to_csv(OUT / "referencia" / "condados.csv", index=False, encoding="utf-8", lineterminator="\n")
anios = [leer(d / "referencia" / "anios.csv") for d in GRUPOS.values()]
assert all(a.equals(anios[0]) for a in anios)
anios[0].to_csv(OUT / "referencia" / "anios.csv", index=False, encoding="utf-8", lineterminator="\n")

vacias = []
for t, claves in CLAVES.items():
    partes = {g: leer(d / t) for g, d in GRUPOS.items()}
    cols = list(partes["ia_il_in"].columns)
    for g, df in partes.items():
        assert list(df.columns) == cols, (t, g)
        v = (df == "").mean() * 100
        vacias += [{"tabla": t, "grupo": g, "columna": c, "pct_vacias": round(v[c], 1), "filas": len(df)} for c in cols]
    todo = pd.concat(partes.values(), ignore_index=True)
    assert not todo.duplicated(subset=claves).any(), t
    assert todo["fips"].str.fullmatch(r"\d{5}").all() and todo["fips"].isin(cond["fips"]).all(), t
    todo = (todo.assign(_a=todo["anio"].astype(int))
            .sort_values(["fips", "_a"] + claves[2:], kind="mergesort").drop(columns="_a"))
    todo.to_csv(OUT / t, index=False, encoding="utf-8", lineterminator="\n")
    print(t, todo.shape, "condados:", todo["fips"].nunique(), "estados:", todo["fips"].str[:2].nunique())

v = pd.DataFrame(vacias)
ancho = v.pivot_table(index=["tabla", "columna"], columns="grupo", values="pct_vacias", sort=False).reset_index()
orden = {c: i for t in CLAVES for i, c in enumerate(leer(GRUPOS["ia_il_in"] / t).columns[:0])}
ancho = ancho[["tabla", "columna", *GRUPOS]]
ancho.to_csv(OUT / "columnas_vacias.csv", index=False, encoding="utf-8", lineterminator="\n")
solo_v3 = ancho[(ancho["ia_il_in"] < 100) & (ancho[[g for g in GRUPOS if g != "ia_il_in"]] == 100).all(axis=1)]
print("columnas con dato solo en IA/IL/IN:", len(solo_v3))
print(solo_v3[["tabla", "columna", "ia_il_in"]].to_string(index=False))
