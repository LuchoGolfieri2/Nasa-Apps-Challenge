"""Compara encabezados de CSV por paquete: v3 (_trabajo_v3/data/processed) contra los releases por paquete.

Uso: comparar_columnas.py <trabajo_v3> <carpeta_todo> <salida.csv>
Escribe una fila por (paquete, archivo, grupo) con columnas solo en v3, solo en el release y orden distinto.
"""
import csv
import sys
from pathlib import Path

V3 = Path(sys.argv[1]) / "data" / "processed"
TODO = Path(sys.argv[2])
OUT = Path(sys.argv[3])


def cab(p: Path) -> list[str]:
    with open(p, encoding="utf-8", newline="") as f:
        return next(csv.reader(f), [])


def archivos_v3():
    d = {}
    for p in V3.glob("*/*.csv"):
        d[(p.parent.name, p.name)] = cab(p)
    return d


def archivos_grupo(g: Path):
    d = {}
    for p in g.glob("*/data/processed/*/*.csv"):
        d[(p.parent.name, p.name)] = cab(p)
    return d


v3 = archivos_v3()
filas = []
for g in sys.argv[4:] or ("oh_ne_mn", "mo_wi_sd"):
    rel = archivos_grupo(TODO / g)
    for k in sorted(set(v3) | set(rel)):
        a, b = v3.get(k), rel.get(k)
        if a is None:
            filas.append([*k, g, "solo_release", "", ";".join(b), ""])
            continue
        if b is None:
            filas.append([*k, g, "solo_v3", ";".join(a), "", ""])
            continue
        sa, sb = [c for c in a if c not in b], [c for c in b if c not in a]
        comunes_a = [c for c in a if c in b]
        comunes_b = [c for c in b if c in a]
        estado = "igual" if a == b else ("mismo_conjunto_otro_orden" if not sa and not sb else "distinto")
        filas.append([*k, g, estado, ";".join(sa), ";".join(sb), "si" if comunes_a != comunes_b else ""])
with open(OUT, "w", encoding="utf-8", newline="") as f:
    w = csv.writer(f)
    w.writerow(["paquete", "archivo", "grupo", "estado", "solo_en_v3", "solo_en_release", "orden_distinto"])
    w.writerows(filas)
from collections import Counter
print(Counter((r[2], r[3]) for r in filas))
for r in filas:
    if r[3] != "igual":
        print(r[2], r[0], r[1], r[3], "| v3:", r[4][:150], "| rel:", r[5][:150])
