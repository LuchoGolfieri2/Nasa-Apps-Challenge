"""Arma, para un grupo de estados publicado por paquete, las mismas tablas que la entrega v3 (mismos nombres
y orden de columnas), con el merge.py de la v3.

Uso: armar_unido.py <trabajo_v3> <carpeta_grupo_release> <salida_condado>

- Copia src/merge.py y loop/spec/entregables.yaml de la v3 a un espacio de trabajo nuevo.
- Pone en data/processed/ los CSV del release tal cual.
- Los archivos de paquetes que la v3 tiene y el release no (aptitud, ecostress, hidrologia, teledeteccion,
  validacion) van con solo el encabezado de la v3: sus columnas quedan vacías en las tablas (faltante = vacío)
  y los nombres con prefijo por colisión salen iguales que en la v3.
- Corre merge.py y deja tabla_anual.csv, tabla_mensual.csv, extras/ y referencia/ con la estructura de v3/condado.
"""
import csv
import json
import shutil
import subprocess
import sys
from pathlib import Path

V3 = Path(sys.argv[1])
G = Path(sys.argv[2])
OUT = Path(sys.argv[3])
WS = OUT.parent / f"_ws_{OUT.name}"

EXTRAS = {  # nombre en v3/condado/extras -> paquete/archivo en data/processed
    "clima_diario.csv": "clima/clima_diario.csv", "vegetacion_16d.csv": "vegetacion/vegetacion_16d.csv",
    "agua_diario.csv": "agua/agua_diario.csv", "agua_semanal.csv": "agua/agua_semanal.csv",
    "rotacion_secuencia.csv": "cultivos/rotacion_secuencia.csv", "practicas_censo.csv": "cultivos/practicas_censo.csv",
    "teledeteccion_anual.csv": "teledeteccion/teledeteccion_anual.csv", "economia_anual.csv": "economia/economia_anual.csv",
    "economia_forrajes_anual.csv": "economia/economia_forrajes_anual.csv", "nldas_mensual.csv": "nldas/nldas_mensual.csv",
    "ecostress_mensual.csv": "ecostress/ecostress_mensual.csv",
}


def cab(p: Path) -> list[str]:
    with open(p, encoding="utf-8", newline="") as f:
        return next(csv.reader(f), [])


if WS.exists():
    shutil.rmtree(WS)
(WS / "src").mkdir(parents=True)
(WS / "loop" / "spec").mkdir(parents=True)
shutil.copy2(V3 / "src" / "merge.py", WS / "src" / "merge.py")
shutil.copy2(V3 / "loop" / "spec" / "entregables.yaml", WS / "loop" / "spec" / "entregables.yaml")
proc = WS / "data" / "processed"

reales, vacios = [], []
for p in sorted(G.glob("*/data/processed/*/*.csv")):
    d = proc / p.parent.name
    d.mkdir(parents=True, exist_ok=True)
    shutil.copy2(p, d / p.name)
    reales.append(f"{p.parent.name}/{p.name}")
for p in sorted((V3 / "data" / "processed").glob("*/*.csv")):
    rel = f"{p.parent.name}/{p.name}"
    if p.parent.name == "lotes" or (proc / rel).exists():
        continue
    (proc / p.parent.name).mkdir(parents=True, exist_ok=True)
    with open(proc / rel, "w", encoding="utf-8", newline="") as f:
        csv.writer(f, lineterminator="\n").writerow(cab(p))
    vacios.append(rel)

r = subprocess.run([sys.executable, "-X", "utf8", str(WS / "src" / "merge.py")], capture_output=True, text=True)
print(r.stdout[-3000:])
if r.returncode != 0:
    sys.exit(r.stderr[-3000:])

if OUT.exists():
    shutil.rmtree(OUT)
(OUT / "extras").mkdir(parents=True)
(OUT / "referencia").mkdir()
v3c = V3.parent / "fieldshift_datos_v3" / "condado"
iguales = {}
for t in ("tabla_anual.csv", "tabla_mensual.csv"):
    shutil.move(str(proc / t), OUT / t)
    iguales[t] = cab(OUT / t) == cab(v3c / t)
extras_ok, extras_faltan = {}, []
for nombre, rel in EXTRAS.items():
    if rel in reales:
        shutil.copy2(proc / rel, OUT / "extras" / nombre)
        extras_ok[nombre] = cab(OUT / "extras" / nombre) == cab(v3c / "extras" / nombre)
    else:
        extras_faltan.append(nombre)
for ref in ("condados.csv", "anios.csv"):
    src = next(iter(list(G.glob(f"base/**/{ref}")) or list(G.glob(f"*/data/reference/{ref}"))))
    shutil.copy2(src, OUT / "referencia" / ref)
    iguales[f"referencia/{ref}"] = cab(OUT / "referencia" / ref) == cab(v3c / "referencia" / ref)
shutil.rmtree(WS)
res = {"tablas_y_referencia_iguales_a_v3": iguales, "extras_iguales_a_v3": extras_ok,
       "extras_que_no_hay": extras_faltan, "archivos_vacios_con_encabezado_v3": vacios}
(OUT.parent / f"{OUT.name}_resumen.json").write_text(json.dumps(res, ensure_ascii=False, indent=1), encoding="utf-8")
print(json.dumps(res, ensure_ascii=False, indent=1))
