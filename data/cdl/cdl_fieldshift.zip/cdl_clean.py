#!/usr/bin/env python3
"""
cdl_clean.py — Limpieza del Cropland Data Layer (USDA CropScape) para Field Shift.

Entrada : carpeta con GeoTIFFs del CDL, uno por año (como los baja CropScape,
          p. ej. CDL_2023_19153.tif). El año se toma del nombre del archivo.
Salida  :
  interim/cdl_grupos_<año>.tif     raster reclasificado a grupos (uint8), grilla común
  processed/cdl_puntos.csv         region, point_id, lat, lon, year, crop_t, crop_t1, crop_t2,
                                   n_maiz_prev, n_soja_prev, n_trigo_prev, n_anios_prev
                                   (veces que se sembró cada cultivo ANTES de 'year')
  processed/cdl_transiciones.csv   conteo cultivo año anterior -> cultivo año actual
  processed/cdl_superficie.csv     hectáreas por grupo y año
  processed/cdl_qa.txt             reporte de calidad (sin dato, nubes, códigos sin mapear)

Supuestos del CDL (según el metadata 2025 de NASS):
  - Albers Conical Equal Area (NAD83). 2008–2024: 30 m. 2025: 10 m.
    Todos los años se llevan a la grilla MÁS GRUESA (30 m); los de 10 m se
    agregan con la moda (clase más frecuente), nunca se inventa detalle.
  - Valor 0 = fondo / sin dato; 81 = nubes / sin dato.
  - Cultivos: 1–61, 66–80, 200–255, salvo 37, 59 y 60 (lista oficial del
    Cultivated Layer). No agrícola: 37, 59, 60, 62–65, 82–199.
  - Opcional: --mascara-cultivada con el Cultivated Layer de NASS
    (1 = no cultivado, 2 = cultivado, 0 = sin dato) para restringir el muestreo.

Uso:
  python cdl_clean.py --raw raw/cdl --out . --n-puntos 3000 --seed 42
"""
from __future__ import annotations

import argparse
import re
from pathlib import Path

import numpy as np
import pandas as pd
import rasterio
from rasterio.warp import Resampling, reproject, transform as warp_transform

# ---------------------------------------------------------------- grupos
# id de grupo -> nombre. 0 = sin dato, 1 = no agrícola. Los cultivos van de 10 en adelante.
GRUPOS = {
    0: None,              # sin dato -> celda vacía en el CSV
    1: "no_agricola",
    10: "maiz",
    11: "soja",
    12: "trigo",
    13: "sorgo",
    14: "alfalfa",
    15: "doble_trigo_soja",
    16: "otros_dobles",
    17: "barbecho",
    18: "otros_cultivos",
}
CULTIVOS = [g for g in GRUPOS if g >= 10]

CODIGOS = {
    10: [1, 12, 13],                 # maíz, maíz dulce, maíz pisingallo
    11: [5],                         # soja
    12: [22, 23, 24],                # trigo candeal, de primavera, de invierno
    13: [4],                         # sorgo
    14: [36, 58],                    # alfalfa, trébol
    15: [26],                        # doble cultivo trigo invierno / soja
    16: [225, 226, 228, 230, 231, 232, 233, 234, 235, 236, 237, 238, 239, 240, 241, 254],  # otros dobles
    17: [61],                        # barbecho / tierra ociosa
}
# 37 (otros henos), 59 (césped/semilla de pasto) y 60 (switchgrass) son NO cultivados
# según la lista oficial del Cultivated Layer de NASS.
NO_AGRICOLA = [37, 59, 60] + list(range(62, 66)) + list(range(82, 200))
SIN_DATO = [0, 81]

# Códigos por cultivo para contar frecuencia, igual que los Crop Frequency Layers de NASS
# (un doble cultivo suma en los dos cultivos).
FRECUENCIA = {
    "maiz": [1, 225, 226, 228, 237, 241],
    "soja": [5, 26, 239, 240, 241, 254],
    "trigo": [22, 23, 24, 26, 225, 230, 234, 236, 238],
}


def construir_lut() -> np.ndarray:
    """Tabla de 256 posiciones: código CDL -> id de grupo."""
    lut = np.zeros(256, dtype=np.uint8)
    cultivo_generico = list(range(1, 62)) + list(range(66, 81)) + list(range(200, 256))
    lut[cultivo_generico] = 18
    lut[NO_AGRICOLA] = 1
    for grupo, cods in CODIGOS.items():
        lut[cods] = grupo
    lut[SIN_DATO] = 0
    return lut


# ---------------------------------------------------------------- E/S
def encontrar_archivos(raw: Path) -> dict[int, Path]:
    archivos = {}
    for f in sorted(raw.glob("*.tif")):
        m = re.search(r"(19|20)\d{2}", f.name)
        if m:
            anio = int(m.group(0))
            if anio in archivos:
                raise SystemExit(f"Hay dos archivos para {anio}: {archivos[anio].name} y {f.name}")
            archivos[anio] = f
    if len(archivos) < 3:
        raise SystemExit(f"Se necesitan ≥3 años para armar rotaciones; encontré {sorted(archivos)}")
    return archivos


def leer_en_grilla(path: Path, ref: dict, remuestreo: str = "moda") -> np.ndarray:
    """Lee un año y, si su grilla no coincide con la de referencia, lo lleva a esa grilla.
    Si el archivo es más fino (10 m -> 30 m) usa la moda; si no, vecino más cercano."""
    with rasterio.open(path) as src:
        misma = (src.crs == ref["crs"] and src.transform == ref["transform"]
                 and (src.height, src.width) == (ref["height"], ref["width"]))
        if misma:
            return src.read(1)
        dst = np.zeros((ref["height"], ref["width"]), dtype=np.uint8)
        reproject(source=rasterio.band(src, 1), destination=dst,
                  dst_transform=ref["transform"], dst_crs=ref["crs"],
                  src_nodata=0, dst_nodata=0,
                  resampling=(Resampling.mode if remuestreo == "moda" and abs(src.res[0]) < abs(ref["transform"].a)
                              else Resampling.nearest))
        return dst


# ---------------------------------------------------------------- pipeline
def main() -> None:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--raw", type=Path, required=True, help="carpeta con los GeoTIFF del CDL (no se modifica)")
    ap.add_argument("--out", type=Path, default=Path("."), help="raíz donde crear interim/ y processed/")
    ap.add_argument("--n-puntos", type=int, default=3000)
    ap.add_argument("--seed", type=int, default=42)
    ap.add_argument("--region", default="", help="etiqueta de la zona (p. ej. el FIPS del condado)")
    ap.add_argument("--remuestreo", choices=["moda", "cercano"], default="moda",
                    help="cómo pasar el CDL 2025 (10 m) a 30 m. 'cercano' = igual que NASS en el Cultivated Layer")
    ap.add_argument("--mascara-cultivada", type=Path, default=None,
                    help="GeoTIFF del Cultivated Layer de NASS; solo se muestrean píxeles con valor 2")
    args = ap.parse_args()

    interim, processed = args.out / "interim", args.out / "processed"
    interim.mkdir(parents=True, exist_ok=True)
    processed.mkdir(parents=True, exist_ok=True)

    archivos = encontrar_archivos(args.raw)
    anios = sorted(archivos)
    faltan = sorted(set(range(anios[0], anios[-1] + 1)) - set(anios))
    if faltan:
        print(f"AVISO: faltan los años {faltan}; esas rotaciones se saltean.")
    lut = construir_lut()

    # grilla de referencia: el año con píxel más grueso (30 m); a igualdad, el más reciente
    def tam_pixel(a):
        with rasterio.open(archivos[a]) as s_:
            return abs(s_.res[0])
    anio_ref = max(anios, key=lambda a: (tam_pixel(a), a))
    with rasterio.open(archivos[anio_ref]) as src:
        ref = dict(crs=src.crs, transform=src.transform, height=src.height, width=src.width)
        perfil = src.profile.copy()
    print(f"Grilla de referencia: {anio_ref} ({abs(ref['transform'].a):.0f} m)")
    perfil.update(dtype="uint8", count=1, nodata=0, compress="deflate")
    ha_por_pixel = abs(ref["transform"].a * ref["transform"].e) / 10_000

    qa, superficie, pila = [], [], []
    frec = {c: [] for c in FRECUENCIA}
    for anio in anios:
        crudo = leer_en_grilla(archivos[anio], ref, args.remuestreo)
        grupos = lut[crudo]
        pila.append(grupos)
        for c, cods in FRECUENCIA.items():
            frec[c].append(np.isin(crudo, cods))

        total = crudo.size
        sin_mapear = np.setdiff1d(np.unique(crudo),
                                  np.concatenate([np.flatnonzero(lut), SIN_DATO]))
        qa.append(f"{anio}: sin dato {np.isin(crudo, [0]).mean():.1%} | nubes(81) {(crudo == 81).mean():.2%}"
                  f" | códigos sin mapear: {sin_mapear.tolist() or 'ninguno'}")

        conteo = np.bincount(grupos.ravel(), minlength=256)
        for g in CULTIVOS + [1]:
            superficie.append({"year": anio, "grupo": GRUPOS[g], "sup_ha": round(conteo[g] * ha_por_pixel, 1)})

        with rasterio.open(interim / f"cdl_grupos_{anio}.tif", "w", **perfil) as dst:
            dst.write(grupos, 1)

    pila = np.stack(pila)                                     # (años, filas, cols)
    frec = {c: np.stack(v) for c, v in frec.items()}

    # --- muestreo: píxeles que fueron cultivo TODOS los años
    es_cultivo = np.isin(pila, CULTIVOS).all(axis=0)
    if args.mascara_cultivada:
        cult = leer_en_grilla(args.mascara_cultivada, ref, "cercano")
        qa.append(f"Cultivated Layer: {(cult == 2).mean():.1%} del área marcada como cultivada")
        es_cultivo &= cult == 2
    filas, cols = np.nonzero(es_cultivo)
    if filas.size == 0:
        raise SystemExit("Ningún píxel es cultivo en todos los años: revisar el recorte o la grilla.")
    rng = np.random.default_rng(args.seed)
    idx = rng.choice(filas.size, size=min(args.n_puntos, filas.size), replace=False)
    filas, cols = filas[idx], cols[idx]

    xs, ys = rasterio.transform.xy(ref["transform"], filas, cols)  # centro del píxel
    lons, lats = warp_transform(ref["crs"], "EPSG:4326", list(xs), list(ys))

    nombre = np.array([GRUPOS.get(g) or "" for g in range(256)], dtype=object)
    registros = []
    for k in range(len(idx)):
        serie = pila[:, filas[k], cols[k]]
        acum = {c: np.concatenate([[0], np.cumsum(frec[c][:, filas[k], cols[k]])]) for c in frec}
        for i in range(2, len(anios)):                         # hacen falta 2 años previos CONSECUTIVOS
            if anios[i] - anios[i - 2] != 2:
                continue
            registros.append({
                "region": args.region,
                "point_id": f"{args.region}_p{k:05d}" if args.region else f"p{k:05d}",
                "lat": round(lats[k], 6), "lon": round(lons[k], 6),
                "year": anios[i],
                "crop_t": nombre[serie[i]],
                "crop_t1": nombre[serie[i - 1]],
                "crop_t2": nombre[serie[i - 2]],
                # solo años anteriores a 'year' -> sin fuga del objetivo
                "n_maiz_prev": int(acum["maiz"][i]),
                "n_soja_prev": int(acum["soja"][i]),
                "n_trigo_prev": int(acum["trigo"][i]),
                "n_anios_prev": i,
            })
    puntos = pd.DataFrame(registros)
    puntos.to_csv(processed / "cdl_puntos.csv", index=False)

    # --- matriz de transiciones (sobre todos los píxeles agrícolas, no solo la muestra)
    trans = []
    for i in range(1, len(anios)):
        if anios[i] - anios[i - 1] != 1:                       # no comparar años salteados
            continue
        a, b = pila[i - 1].ravel(), pila[i].ravel()
        m = np.isin(a, CULTIVOS) & np.isin(b, CULTIVOS)
        pares = pd.Series(a[m].astype(np.uint16) * 256 + b[m]).value_counts()
        for codigo, n in pares.items():
            trans.append({"year": anios[i], "crop_t1": GRUPOS[codigo // 256],
                          "crop_t": GRUPOS[codigo % 256], "pixeles": int(n)})
    pd.DataFrame(trans).to_csv(processed / "cdl_transiciones.csv", index=False)
    pd.DataFrame(superficie).to_csv(processed / "cdl_superficie.csv", index=False)

    qa.append(f"Píxeles cultivo todos los años: {es_cultivo.sum():,} | muestreados: {len(idx):,}"
              f" | filas en cdl_puntos.csv: {len(puntos):,}")
    (processed / "cdl_qa.txt").write_text("\n".join(qa) + "\n", encoding="utf-8")
    print("\n".join(qa))


if __name__ == "__main__":
    main()
