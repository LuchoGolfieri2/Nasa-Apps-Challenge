#!/usr/bin/env python3
"""
fetch_cdl.py — Baja el CDL recortado por condado desde la API de CropScape.

  python fetch_cdl.py --fips 19169 17113 20191 --anios 2015-2025 --out raw/cdl

Deja raw/cdl/<fips>/CDL_<año>_<fips>.tif. Si un archivo ya existe, no lo vuelve a bajar.
API: https://nassgeodata.gmu.edu/axis2/services/CDLService/GetCDLFile?year=<año>&fips=<fips>
"""
import argparse
import re
import time
import urllib.request
from pathlib import Path

API = "https://nassgeodata.gmu.edu/axis2/services/CDLService/GetCDLFile?year={anio}&fips={fips}"


def obtener(url: str, intentos: int = 3, timeout: int = 180) -> bytes:
    for i in range(intentos):
        try:
            with urllib.request.urlopen(url, timeout=timeout) as r:
                return r.read()
        except Exception as e:                      # red inestable: reintentar con espera
            if i == intentos - 1:
                raise
            print(f"  reintento ({e})")
            time.sleep(5 * (i + 1))


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--fips", nargs="+", required=True)
    ap.add_argument("--anios", default="2015-2025")
    ap.add_argument("--out", type=Path, default=Path("raw/cdl"))
    a = ap.parse_args()
    ini, fin = map(int, a.anios.split("-"))

    for fips in a.fips:
        carpeta = a.out / fips
        carpeta.mkdir(parents=True, exist_ok=True)
        for anio in range(ini, fin + 1):
            destino = carpeta / f"CDL_{anio}_{fips}.tif"
            if destino.exists() and destino.stat().st_size > 0:
                print(f"{fips} {anio}: ya está")
                continue
            xml = obtener(API.format(anio=anio, fips=fips)).decode("utf-8", "replace")
            m = re.search(r"<returnURL>(.*?)</returnURL>", xml)
            if not m:
                print(f"{fips} {anio}: la API no devolvió archivo -> {xml[:200]!r}")
                continue
            destino.write_bytes(obtener(m.group(1)))
            print(f"{fips} {anio}: {destino.stat().st_size / 1e6:.1f} MB")


if __name__ == "__main__":
    main()
